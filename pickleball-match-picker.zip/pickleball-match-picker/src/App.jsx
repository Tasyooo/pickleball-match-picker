import { useMemo, useState } from "react";
import "./App.css";

const makePlayers = () =>
  Array.from({ length: 12 }, (_, index) => ({
    id: index + 1,
    name: `Player ${index + 1}`,
  }));

function shuffle(items) {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

function generateSchedule(players) {
  const games = [];
  for (let round = 1; round <= 5; round += 1) {
    const ids = shuffle(players.map((player) => player.id));
    for (let court = 0; court < 3; court += 1) {
      games.push({
        id: games.length + 1,
        round,
        court: court + 1,
        players: ids.slice(court * 4, court * 4 + 4),
        scoreA: "",
        scoreB: "",
        completed: false,
      });
    }
  }
  return games;
}

function App() {
  const [players, setPlayers] = useState(makePlayers);
  const [schedule, setSchedule] = useState(() => generateSchedule(makePlayers()));
  const [editingGame, setEditingGame] = useState(null);

  const playerName = (id) => players.find((player) => player.id === id)?.name || "Unknown";

  const appearances = useMemo(() => {
    const counts = Object.fromEntries(players.map((player) => [player.id, 0]));
    schedule.forEach((game) => game.players.forEach((id) => { counts[id] += 1; }));
    return counts;
  }, [players, schedule]);

  const rankings = useMemo(() => players.map((player) => {
    let wins = 0;
    let losses = 0;
    let pointsFor = 0;
    let pointsAgainst = 0;

    schedule.forEach((game) => {
      if (!game.completed || !game.players.includes(player.id)) return;
      const isTeamA = game.players.slice(0, 2).includes(player.id);
      const ownScore = Number(isTeamA ? game.scoreA : game.scoreB);
      const otherScore = Number(isTeamA ? game.scoreB : game.scoreA);
      pointsFor += ownScore;
      pointsAgainst += otherScore;
      if (ownScore > otherScore) wins += 1;
      else losses += 1;
    });

    const played = wins + losses;
    return {
      ...player,
      wins,
      losses,
      played,
      winRate: played ? (wins / played) * 100 : 0,
      differential: pointsFor - pointsAgainst,
    };
  }).sort((a, b) =>
    b.wins - a.wins ||
    b.winRate - a.winRate ||
    b.differential - a.differential ||
    a.name.localeCompare(b.name)
  ), [players, schedule]);

  function renamePlayer(id, name) {
    setPlayers((current) => current.map((player) =>
      player.id === id ? { ...player, name } : player
    ));
  }

  function randomize() {
    setSchedule(generateSchedule(players));
    setEditingGame(null);
  }

  function updateMatchup(gameId, slot, selectedId) {
    const playerId = Number(selectedId);
    setSchedule((current) => current.map((game) => {
      if (game.id !== gameId) return game;
      const nextPlayers = [...game.players];
      const otherSlot = nextPlayers.indexOf(playerId);

      // If the selected player is already in this game, swap their positions.
      // Otherwise replace the selected slot with the new player.
      if (otherSlot !== -1 && otherSlot !== slot) {
        [nextPlayers[slot], nextPlayers[otherSlot]] = [nextPlayers[otherSlot], nextPlayers[slot]];
      } else {
        nextPlayers[slot] = playerId;
      }
      return { ...game, players: nextPlayers };
    }));
  }

  function updateScore(gameId, field, value) {
    // Only non-negative whole-number scores are accepted.
    if (value !== "" && (!/^\d+$/.test(value) || Number(value) < 0)) return;
    setSchedule((current) => current.map((game) => {
      if (game.id !== gameId) return game;
      const updated = { ...game, [field]: value };
      const bothEntered = updated.scoreA !== "" && updated.scoreB !== "";
      updated.completed = bothEntered && Number(updated.scoreA) !== Number(updated.scoreB);
      return updated;
    }));
  }

  function clearScore(gameId) {
    setSchedule((current) => current.map((game) =>
      game.id === gameId
        ? { ...game, scoreA: "", scoreB: "", completed: false }
        : game
    ));
  }

  const completedGames = schedule.filter((game) => game.completed).length;

  return (
    <main className="app-shell">
      <header className="hero">
        <div className="brand-mark" aria-hidden="true">🏓</div>
        <div className="hero-copy">
          <p className="eyebrow">DOUBLES · ROUND SCHEDULER</p>
          <h1>Pickleball Match Picker</h1>
          <p className="subtitle">Random teams, editable matchups, and live player rankings.</p>
        </div>
        <button className="button button-primary hero-action" onClick={randomize}>
          <span aria-hidden="true">↻</span> Randomize schedule
        </button>
      </header>

      <section className="stats-grid" aria-label="Schedule summary">
        <div className="stat-card"><span className="stat-label">Players</span><strong>12</strong><span className="stat-note">Active roster</span></div>
        <div className="stat-card"><span className="stat-label">Total games</span><strong>15</strong><span className="stat-note">3 courts × 5 rounds</span></div>
        <div className="stat-card"><span className="stat-label">Games recorded</span><strong>{completedGames}<small> / 15</small></strong><span className="stat-note">Results entered</span></div>
      </section>

      <section className="section-card roster-card">
        <div className="section-title-row">
          <div>
            <p className="section-kicker">SETUP</p>
            <h2>Player roster</h2>
            <p className="section-description">Edit names here. Match cards and rankings update automatically.</p>
          </div>
          <span className="pill">12 players</span>
        </div>
        <div className="player-grid">
          {players.map((player) => (
            <label className="player-field" key={player.id}>
              <span className="player-index">{String(player.id).padStart(2, "0")}</span>
              <input
                value={player.name}
                maxLength={32}
                onChange={(event) => renamePlayer(player.id, event.target.value)}
                aria-label={`Name for player ${player.id}`}
              />
              <span className="appearance-count" title="Current scheduled appearances">{appearances[player.id]}×</span>
            </label>
          ))}
        </div>
        <p className="roster-footnote">Each player starts with 5 scheduled appearances. Manual edits may change this count.</p>
      </section>

      <section className="schedule-section">
        <div className="section-title-row schedule-title">
          <div>
            <p className="section-kicker">ON THE COURT</p>
            <h2>Match schedule</h2>
            <p className="section-description">Enter the final score for each game to update the rankings.</p>
          </div>
          <span className="pill pill-light">5 rounds · 3 courts</span>
        </div>

        {[1, 2, 3, 4, 5].map((round) => (
          <section className="round-section" key={round}>
            <div className="round-heading"><span className="round-number">{String(round).padStart(2, "0")}</span><h3>Round {round}</h3><span className="round-line" /></div>
            <div className="games-grid">
              {schedule.filter((game) => game.round === round).map((game) => (
                <article className="game-card" key={game.id}>
                  <div className="game-card-header">
                    <div><span className="game-label">GAME {String(game.id).padStart(2, "0")}</span><h4>Court {game.court}</h4></div>
                    <button className="button button-quiet" onClick={() => setEditingGame(editingGame === game.id ? null : game.id)}>
                      {editingGame === game.id ? "Done editing" : "✎ Edit teams"}
                    </button>
                  </div>

                  <div className="teams-row">
                    <div className="team team-a">
                      <span className="team-label">TEAM A</span>
                      <strong>{playerName(game.players[0])}</strong>
                      <strong>{playerName(game.players[1])}</strong>
                    </div>
                    <span className="versus">VS</span>
                    <div className="team team-b">
                      <span className="team-label">TEAM B</span>
                      <strong>{playerName(game.players[2])}</strong>
                      <strong>{playerName(game.players[3])}</strong>
                    </div>
                  </div>

                  {editingGame === game.id && (
                    <div className="match-editor">
                      <p className="editor-title">Edit the four player slots</p>
                      {game.players.map((playerId, slot) => (
                        <label className="edit-field" key={slot}>
                          <span>{slot < 2 ? "Team A" : "Team B"} · Player {(slot % 2) + 1}</span>
                          <select value={playerId} onChange={(event) => updateMatchup(game.id, slot, event.target.value)}>
                            {players.map((player) => <option value={player.id} key={player.id}>{player.name}</option>)}
                          </select>
                        </label>
                      ))}
                      <p className="editor-hint">Choosing a player already in this game swaps their positions. Other choices replace the selected slot.</p>
                    </div>
                  )}

                  <div className="score-area">
                    <span className="score-label">FINAL SCORE</span>
                    <div className="score-inputs">
                      <label><span className="sr-only">Team A score</span><input inputMode="numeric" pattern="[0-9]*" value={game.scoreA} placeholder="0" onChange={(event) => updateScore(game.id, "scoreA", event.target.value)} aria-label={`Game ${game.id} Team A score`} /></label>
                      <span className="score-dash">:</span>
                      <label><span className="sr-only">Team B score</span><input inputMode="numeric" pattern="[0-9]*" value={game.scoreB} placeholder="0" onChange={(event) => updateScore(game.id, "scoreB", event.target.value)} aria-label={`Game ${game.id} Team B score`} /></label>
                      {game.completed && <span className="result-check" title="Result recorded">✓</span>}
                    </div>
                    {game.scoreA !== "" && game.scoreB !== "" && Number(game.scoreA) === Number(game.scoreB)
                      ? <p className="score-hint warning">Scores are tied. Enter a winner to count the game.</p>
                      : <p className="score-hint">{game.completed ? "Result recorded in rankings" : "Enter both scores to record result"}</p>}
                    {(game.scoreA !== "" || game.scoreB !== "") && <button className="clear-score" onClick={() => clearScore(game.id)}>Clear score</button>}
                  </div>
                </article>
              ))}
            </div>
          </section>
        ))}
      </section>

      <section className="section-card rankings-card">
        <div className="section-title-row">
          <div>
            <p className="section-kicker">LEADERBOARD</p>
            <h2>Player rankings</h2>
            <p className="section-description">Standings update automatically as valid scores are entered.</p>
          </div>
          <span className="trophy-mark" aria-hidden="true">🏆</span>
        </div>
        <div className="table-wrap">
          <table className="ranking-table">
            <thead><tr><th>Rank</th><th>Player</th><th>Played</th><th>Wins</th><th>Losses</th><th>Win %</th><th>Point diff.</th></tr></thead>
            <tbody>
              {rankings.map((player, index) => (
                <tr key={player.id}>
                  <td><span className={`rank-badge ${index < 3 ? `rank-${index + 1}` : ""}`}>{index + 1}</span></td>
                  <td className="ranking-player">{player.name || `Player ${player.id}`}</td>
                  <td>{player.played}</td>
                  <td className="wins-cell">{player.wins}</td>
                  <td>{player.losses}</td>
                  <td>{player.winRate.toFixed(0)}%</td>
                  <td className={player.differential > 0 ? "positive-diff" : player.differential < 0 ? "negative-diff" : ""}>{player.differential > 0 ? "+" : ""}{player.differential}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="ranking-note">Tie-break order: wins, win percentage, then point differential. Unplayed games do not affect rankings.</p>
      </section>

      <footer className="app-footer"><span>Pickleball Match Picker</span><span>12 players · 5 rounds · 15 games</span></footer>
    </main>
  );
}

export default App;
